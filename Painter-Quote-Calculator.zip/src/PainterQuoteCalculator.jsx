import { useState } from "react";

export default function PainterQuoteCalculator() {
  const [painters, setPainters] = useState(2);
  const [dailyRate, setDailyRate] = useState(150);
  const [days, setDays] = useState(1);
  const [overheadPercent, setOverheadPercent] = useState(15);
  const [profitMarginPercent, setProfitMarginPercent] = useState(40);

  const labourCost = painters * dailyRate * days;
  const overhead = (labourCost * overheadPercent) / 100;
  const totalCost = labourCost + overhead;
  const profit = (totalCost * profitMarginPercent) / 100;
  const finalQuote = totalCost + profit;

  return (
    <div style={{ padding: '1rem', maxWidth: '400px', margin: '0 auto', fontFamily: 'Arial' }}>
      <h1>Painter Quote Calculator</h1>
      <label>Number of Painters</label>
      <input type="number" value={painters} onChange={e => setPainters(+e.target.value)} /><br />
      <label>Daily Rate per Painter (£)</label>
      <input type="number" value={dailyRate} onChange={e => setDailyRate(+e.target.value)} /><br />
      <label>Job Length (Days)</label>
      <input type="number" value={days} onChange={e => setDays(+e.target.value)} /><br />
      <label>Overhead %</label>
      <input type="number" value={overheadPercent} onChange={e => setOverheadPercent(+e.target.value)} /><br />
      <label>Profit Margin %</label>
      <input type="number" value={profitMarginPercent} onChange={e => setProfitMarginPercent(+e.target.value)} /><br />
      <div style={{ backgroundColor: '#f0f0f0', padding: '1rem', borderRadius: '8px', marginTop: '1rem' }}>
        <p><strong>Labour Cost:</strong> £{labourCost.toFixed(2)}</p>
        <p><strong>Overhead:</strong> £{overhead.toFixed(2)}</p>
        <p><strong>Total Cost:</strong> £{totalCost.toFixed(2)}</p>
        <p><strong>Profit:</strong> £{profit.toFixed(2)}</p>
        <p><strong>Final Quote:</strong> £{finalQuote.toFixed(2)}</p>
      </div>
    </div>
  );
}