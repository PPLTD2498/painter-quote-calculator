import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import PainterQuoteCalculator from './PainterQuoteCalculator';

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <PainterQuoteCalculator />
  </React.StrictMode>
);